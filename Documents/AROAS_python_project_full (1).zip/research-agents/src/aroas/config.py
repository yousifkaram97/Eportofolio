from pathlib import Path
import os

BASE_DIR = Path(__file__).resolve().parent.parent.parent  # points to .../src
PROJECT_ROOT = BASE_DIR.parent  # .../research-agents
DATA_DIR = PROJECT_ROOT / "data"
DATA_DIR.mkdir(exist_ok=True)

REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")
DB_URL = os.getenv("DB_URL", f"sqlite:///{(PROJECT_ROOT/'aroas.db').as_posix()}")
PARQUET_PATH = PROJECT_ROOT / "data" / "export.parquet"
CSV_SAMPLE_PATH = PROJECT_ROOT / "data" / "topk_sample.csv"
SEED = 13
