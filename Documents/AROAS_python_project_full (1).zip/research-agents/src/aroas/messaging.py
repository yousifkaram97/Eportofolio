import json
from dataclasses import dataclass
from typing import Any, Dict
import redis
from .config import REDIS_URL

@dataclass
class Bus:
    channel: str = "aroas"
    def __post_init__(self):
        self._r = redis.from_url(REDIS_URL)
    def publish(self, msg: Dict[str, Any]):
        self._r.publish(self.channel, json.dumps(msg))
