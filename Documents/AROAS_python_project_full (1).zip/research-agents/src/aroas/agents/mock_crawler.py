from dataclasses import dataclass
from typing import List, Dict
from ..processor import clean_html

@dataclass
class MockCrawler:
    """In-memory mock crawler used for demos and tests."""
    seeds: List[Dict]

    def run(self) -> List[Dict]:
        results = []
        for it in self.seeds:
            html = it.get("html", "")
            title = it.get("title") or "Untitled"
            abstract = clean_html(html) if html else it.get("abstract","")
            results.append({
                "url": it.get("url","https://permitted.test/mock"),
                "title": title,
                "abstract": abstract,
                "authors": it.get("authors", []),
                "year": it.get("year", 2025),
            })
        return results
