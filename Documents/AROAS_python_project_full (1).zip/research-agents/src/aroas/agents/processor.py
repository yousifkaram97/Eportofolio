from bs4 import BeautifulSoup
import re
from .ranking import TfidfRanker

CLEAN_RE = re.compile(r"\s+")

def clean_html(html: str) -> str:
    """Strip tags and normalise whitespace."""
    soup = BeautifulSoup(html or "", "lxml")
    text = soup.get_text(" ")
    return CLEAN_RE.sub(" ", text).strip()

def build_ranker() -> TfidfRanker:
    return TfidfRanker()
