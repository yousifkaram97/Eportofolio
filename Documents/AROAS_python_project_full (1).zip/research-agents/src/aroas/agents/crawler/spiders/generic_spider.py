import scrapy

class GenericScholarSpider(scrapy.Spider):
    name = "generic_scholar"
    allowed_domains = ["example.org"]  # replace with permitted test domain
    start_urls = ["https://example.org/"]

    custom_settings = {
        "AUTOTHROTTLE_ENABLED": True,
        "ROBOTSTXT_OBEY": True,
        "CONCURRENT_REQUESTS_PER_DOMAIN": 2,
    }

    def parse(self, response):
        yield {
            "url": response.url,
            "title": response.css("title::text").get(default="Example"),
            "abstract": "",
            "authors": [],
            "year": 2025,
        }
