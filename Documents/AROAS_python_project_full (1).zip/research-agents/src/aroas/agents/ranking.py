from sklearn.feature_extraction.text import TfidfVectorizer
import pandas as pd
from typing import List, Dict

class TfidfRanker:
    """Simple, explainable TF–IDF ranker for short scholarly texts."""
    def __init__(self, stop_words: str = "english", ngram_range=(1,2)):
        self.v = TfidfVectorizer(stop_words=stop_words, ngram_range=ngram_range)
    def fit_transform(self, docs: List[str]):
        return self.v.fit_transform(docs)
    def topk(self, records: List[Dict], query: str, k: int = 10) -> pd.DataFrame:
        docs = [f"{r.get('title','')} {r.get('abstract','')}" for r in records]
        X = self.v.fit_transform(docs + [query])
        qv = X[-1]
        sims = (X[:-1] @ qv.T).toarray().ravel()
        order = sims.argsort()[::-1][:k]
        top = []
        for idx in order:
            rec = records[idx].copy()
            rec["score"] = float(sims[idx])
            top.append(rec)
        return pd.DataFrame(top)
