from sqlalchemy import create_engine, Column, Integer, String, Float
from sqlalchemy.orm import declarative_base, Session
from ..config import DB_URL, PARQUET_PATH, CSV_SAMPLE_PATH
import pandas as pd

Base = declarative_base()

class Paper(Base):
    __tablename__ = "papers"
    id = Column(Integer, primary_key=True, autoincrement=True)
    url = Column(String)
    title = Column(String)
    abstract = Column(String)
    authors = Column(String)
    year = Column(Integer)
    score = Column(Float)

engine = create_engine(DB_URL, future=True)
Base.metadata.create_all(engine)

def persist_topk(df: pd.DataFrame):
    """Persist top‑K results to SQLite and export Parquet/CSV evidence files."""
    with Session(engine) as s:
        for _, row in df.iterrows():
            s.add(Paper(url=row.get("url"),
                        title=row.get("title"),
                        abstract=row.get("abstract"),
                        authors=", ".join(row.get("authors", [])),
                        year=int(row.get("year", 0)),
                        score=float(row.get("score", 0.0))))
        s.commit()
    df.to_parquet(PARQUET_PATH)
    df.head(10).to_csv(CSV_SAMPLE_PATH, index=False)
    return PARQUET_PATH, CSV_SAMPLE_PATH
