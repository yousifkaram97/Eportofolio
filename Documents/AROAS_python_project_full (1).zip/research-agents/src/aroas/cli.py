import argparse, json
from pathlib import Path
from aroas.agents.processor import build_ranker
from aroas.agents.storage import persist_topk
from aroas.agents.mock_crawler import MockCrawler
from aroas.config import PROJECT_ROOT

DATA_DIR = PROJECT_ROOT / "data"
SAMPLE_PATH = DATA_DIR / "sample_records.jsonl"

def load_records(path: Path):
    return [json.loads(l) for l in path.read_text(encoding="utf-8").splitlines()]

def save_records(path: Path, items):
    DATA_DIR.mkdir(exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for r in items:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

def main():
    ap = argparse.ArgumentParser(description="AROAS CLI")
    ap.add_argument("--query", default="machine learning")
    ap.add_argument("--k", type=int, default=10)
    ap.add_argument("--generate-sample", action="store_true", help="Generate sample via mock crawler")
    args = ap.parse_args()

    if args.generate_sample:
        seeds = [
            {"url":"https://permitted.test/1","title":"Machine learning in healthcare","html":"<p>We survey ML for diagnosis.</p>","authors":["Smith","Lee"],"year":2022},
            {"url":"https://permitted.test/2","title":"Statistical learning theory","html":"<p>Margins and VC dimension.</p>","authors":["Vapnik"],"year":2015},
            {"url":"https://permitted.test/3","title":"Neural networks for NLP","html":"<p>Transformers and attention.</p>","authors":["Brown"],"year":2020},
            {"url":"https://permitted.test/4","title":"Graph algorithms in bibliometrics","html":"<p>Centrality and communities.</p>","authors":["Hagberg"],"year":2008},
        ]
        crawler = MockCrawler(seeds=seeds)
        items = crawler.run()
        save_records(SAMPLE_PATH, items)
        print(f"Generated {len(items)} records → {SAMPLE_PATH}")
        return

    if not SAMPLE_PATH.exists():
        raise SystemExit("No sample records found. Run with --generate-sample first.")
    records = load_records(SAMPLE_PATH)
    ranker = build_ranker()
    topk = ranker.topk(records, query=args.query, k=args.k)
    pq, csv = persist_topk(topk)
    print(topk[["title","year","score"]])
    print(f"Parquet: {pq}\nCSV sample: {csv}")

if __name__ == "__main__":
    main()
