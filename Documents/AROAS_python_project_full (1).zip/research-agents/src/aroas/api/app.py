from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import List, Optional
from ..agents.processor import build_ranker, clean_html
from ..agents.storage import persist_topk
from ..config import PROJECT_ROOT
import pandas as pd
import json
from pathlib import Path

app = FastAPI(title="AROAS — Academic Research Online Agent System")

DATA_DIR = PROJECT_ROOT / "data"
SAMPLE_PATH = DATA_DIR / "sample_records.jsonl"
RANKER = build_ranker()

class Record(BaseModel):
    url: str
    title: str
    abstract: str = ""
    authors: List[str] = Field(default_factory=list)
    year: int

class QueryRequest(BaseModel):
    query: str
    k: int = 10

@app.get("/", tags=["health"])
def health():
    return {"status": "ok", "message": "AROAS API is running"}

@app.post("/records/upload", tags=["data"])
def upload_records(records: List[Record]):
    DATA_DIR.mkdir(exist_ok=True)
    with SAMPLE_PATH.open("w", encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(r.dict(), ensure_ascii=False) + "\n")
    return {"ok": True, "count": len(records)}

@app.get("/records/sample", tags=["data"])
def sample_records():
    if not SAMPLE_PATH.exists():
        raise HTTPException(404, "No sample_records.jsonl found.")
    lines = SAMPLE_PATH.read_text(encoding="utf-8").splitlines()
    return {"count": len(lines), "records": [json.loads(l) for l in lines]}

@app.post("/rank", tags=["ranking"])
def rank_query(payload: QueryRequest):
    if not SAMPLE_PATH.exists():
        raise HTTPException(400, "Upload records first via /records/upload.")
    records = [json.loads(l) for l in SAMPLE_PATH.read_text(encoding="utf-8").splitlines()]
    df = RANKER.topk(records, query=payload.query, k=payload.k)
    parquet_path, csv_path = persist_topk(df)
    return {
        "topk": df.to_dict(orient="records"),
        "artifacts": {"parquet": str(parquet_path), "csv": str(csv_path)},
    }
