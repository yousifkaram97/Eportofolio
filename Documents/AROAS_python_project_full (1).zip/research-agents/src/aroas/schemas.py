from typing import TypedDict, List

class RawRecord(TypedDict):
    url: str
    title: str
    abstract: str
    authors: List[str]
    year: int
