import json
from pathlib import Path
from aroas.agents.processor import build_ranker
from aroas.agents.storage import persist_topk
from aroas.config import PROJECT_ROOT

DATA_DIR = PROJECT_ROOT / "data"
SAMPLE_PATH = DATA_DIR / "sample_records.jsonl"

def load_records(path: Path):
    return [json.loads(l) for l in path.read_text(encoding="utf-8").splitlines()]

def main(query: str = "machine learning"):
    records = load_records(SAMPLE_PATH)
    ranker = build_ranker()
    topk = ranker.topk(records, query=query, k=10)
    pq, csv = persist_topk(topk)
    print(topk[["title","year","score"]])
    print(f"Parquet: {pq}\nCSV sample: {csv}")

if __name__ == "__main__":
    main()
