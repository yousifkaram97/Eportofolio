from aroas.agents.ranking import TfidfRanker

def test_topk_orders_by_similarity():
    recs = [
        {"url":"u1","title":"Deep learning for images","abstract":"cnn","authors":["A"],"year":2020},
        {"url":"u2","title":"Statistical methods","abstract":"anova","authors":["B"],"year":2019},
    ]
    r = TfidfRanker()
    df = r.topk(recs, query="deep learning", k=1)
    assert df.iloc[0]["url"] == "u1"
