from aroas.app import main

def test_main_smoke():
    # Smoke test: ensure main runs with default query using bundled sample
    main("machine learning")
