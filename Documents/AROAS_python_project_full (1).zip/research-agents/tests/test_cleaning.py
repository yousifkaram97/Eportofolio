from aroas.agents.processor import clean_html

def test_clean_html_strips_tags():
    html = "<div><h1>Title</h1><p>Text</p></div>"
    assert clean_html(html) == "Title Text"
