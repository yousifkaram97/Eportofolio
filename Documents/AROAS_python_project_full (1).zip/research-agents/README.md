# AROAS — Academic Research Online Agent System

Demonstrable, auditable pipeline for scholarly discovery with ethical crawling,
explainable ranking (TF–IDF), and analytics‑grade Parquet exports.

## Quick start
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
PYTHONPATH=src python -m aroas.app
```

## Tests
```bash
PYTHONPATH=src pytest -q --cov=src
```

Outputs are written to `data/export.parquet` and `data/topk_sample.csv`.

## FastAPI service
Run the API:
```bash
PYTHONPATH=src uvicorn aroas.api.app:app --reload --port 8000
```

Upload records and rank:
```bash
curl -X POST http://localhost:8000/records/upload   -H "Content-Type: application/json"   -d @data/sample_records.jsonl  # (or send a JSON array)

curl -X POST http://localhost:8000/rank -H "Content-Type: application/json"   -d '{"query":"machine learning", "k": 5}'
```

## CLI
```bash
PYTHONPATH=src python -m aroas.cli --generate-sample
PYTHONPATH=src python -m aroas.cli --query "machine learning" --k 10
```
